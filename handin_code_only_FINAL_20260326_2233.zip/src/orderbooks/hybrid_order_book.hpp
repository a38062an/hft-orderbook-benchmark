#pragma once

#include "../core/i_order_book.hpp"
#include <list>
#include <map>
#include <unordered_map>
#include <vector>

namespace hft
{

class HybridOrderBook : public IOrderBook
{
  public:
    HybridOrderBook(Index maxHotLevels = 20);

    void addOrder(const Order &order) override;
    void cancelOrder(OrderId orderId) override;
    void modifyOrder(OrderId orderId, Quantity newQuantity) override;
    std::vector<Trade> match() override;
    Index getOrderCount() const override;

    Price getBestBid() const override;
    Price getBestAsk() const override;

  private:
    using OrderList = std::list<Order>;
    using HotBidsVector = std::vector<std::pair<Price, OrderList>>;
    using HotAsksVector = std::vector<std::pair<Price, OrderList>>;
    using ColdBidsMap = std::map<Price, OrderList, std::greater<Price>>;
    using ColdAsksMap = std::map<Price, OrderList, std::less<Price>>;

    HotBidsVector hotBids_;
    HotAsksVector hotAsks_;
    ColdBidsMap coldBids_;
    ColdAsksMap coldAsks_;

    Index maxHotLevels_;

    // Track where each order lives
    struct OrderLocation
    {
        bool isBuy;
        bool isHot; // true = in vector, false = in map
        Price price;
        OrderList::iterator iterator;
    };

    using OrderLookupMap = std::unordered_map<OrderId, OrderLocation>;

    OrderLookupMap orderLookup_;

    // Helper methods
    bool isCloseToSpread(Price price, bool isBuy) const;
    void promoteToHot(Price price, bool isBuy);
    void demoteFromHot(bool isBuy);
    void addToHot(const Order &order, bool isBuy);
    void addToCold(const Order &order, bool isBuy);
};

} // namespace hft
