#include "map_order_book.hpp"
#include <iostream>

namespace hft
{

// Adds a new order to the book.
// Uses a std::map for price levels (automatically sorted) and a std::list for time priority.
void MapOrderBook::addOrder(const Order &order)
{
    if (orderLookup_.find(order.id) != orderLookup_.end())
    {
        return; // Reject duplicate OrderId
    }

    if (order.side == Side::Buy)
    {
        auto &orderList = bids_[order.price];
        orderList.push_back(order);
        // Store iterator for O(1) lookup/cancellation later
        orderLookup_[order.id] = {true, order.price, --orderList.end()};
    }
    else
    {
        auto &orderList = asks_[order.price];
        orderList.push_back(order);
        orderLookup_[order.id] = {false, order.price, --orderList.end()};
    }
}

// Cancels an existing order by ID.
// Uses the lookup table to find the order's location in O(1) (average) or O(log N).
void MapOrderBook::cancelOrder(OrderId orderId)
{
    auto orderIterator = orderLookup_.find(orderId);
    if (orderIterator == orderLookup_.end())
    {
        return; // Order not found
    }

    const auto &orderLocation = orderIterator->second;
    if (orderLocation.isBuy)
    {
        auto &orderList = bids_[orderLocation.price]; // Get the list of that price
        orderList.erase(orderLocation.iterator);      // Delete the instruments in that price list
        // Clean up empty price levels to keep map size minimal
        if (orderList.empty())
        {
            bids_.erase(orderLocation.price);
        }
    }
    else
    {
        auto &orderList = asks_[orderLocation.price];
        orderList.erase(orderLocation.iterator);
        if (orderList.empty())
        {
            asks_.erase(orderLocation.price);
        }
    }
    orderLookup_.erase(orderIterator);
}

// Modifies the quantity of an existing order.
void MapOrderBook::modifyOrder(OrderId orderId, Quantity newQuantity)
{
    auto orderIterator = orderLookup_.find(orderId);
    if (orderIterator == orderLookup_.end())
    {
        return;
    }

    // If modifying to zero quantity, cancel instead
    if (newQuantity == 0)
    {
        cancelOrder(orderId);
        return;
    }

    // In a real book, increasing size might lose priority.
    // For simplicity here, we just update the quantity in place.
    orderIterator->second.iterator->quantity = newQuantity;
}

// Matches buy and sell orders based on Price-Time priority.
// Returns a vector of executed trades.
std::vector<Trade> MapOrderBook::match()
{
    std::vector<Trade> trades;

    // Continue matching while there are overlapping prices
    while (!bids_.empty() && !asks_.empty())
    {
        auto bestBidIterator = bids_.begin(); // Highest buy price
        auto bestAskIterator = asks_.begin(); // Lowest sell price

        // Check for price overlap (Bid >= Ask)
        if (bestBidIterator->first < bestAskIterator->first)
        {
            break; // No overlap, spread is open
        }

        // Iterator to the best price lists
        auto &bidOrderList = bestBidIterator->second;
        auto &askOrderList = bestAskIterator->second;

        // Match orders at this price level
        while (!bidOrderList.empty() && !askOrderList.empty())
        {
            auto &bidOrder = bidOrderList.front();
            auto &askOrder = askOrderList.front();

            Quantity tradeQty = std::min(bidOrder.quantity, askOrder.quantity);

            trades.push_back({bidOrder.id, askOrder.id, askOrder.price, tradeQty});

            bidOrder.quantity -= tradeQty;
            askOrder.quantity -= tradeQty;

            // Remove filled orders
            if (bidOrder.quantity == 0)
            {
                orderLookup_.erase(bidOrder.id);
                bidOrderList.pop_front();
            }
            if (askOrder.quantity == 0)
            {
                orderLookup_.erase(askOrder.id);
                askOrderList.pop_front();
            }
        }

        // Clean up empty price levels
        if (bidOrderList.empty())
        {
            bids_.erase(bestBidIterator);
        }
        if (askOrderList.empty())
        {
            asks_.erase(bestAskIterator);
        }
    }

    return trades;
}

// Public APIS for future GUI
Index MapOrderBook::getOrderCount() const
{
    return orderLookup_.size();
}

Price MapOrderBook::getBestBid() const
{
    if (bids_.empty())
    {
        return 0; // No bids in the book
    }
    return bids_.begin()->first; // First key is highest price (std::greater)
}

Price MapOrderBook::getBestAsk() const
{
    if (asks_.empty())
    {
        return std::numeric_limits<Price>::max(); // No asks in the book
    }
    return asks_.begin()->first; // First key is lowest price (std::less)
}

} // namespace hft
