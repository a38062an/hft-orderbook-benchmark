#pragma once

#include "core/i_order_book.hpp"
#include <list>
#include <map>
#include <unordered_map>

namespace hft
{

class MapOrderBook : public IOrderBook
{
  public:
    void addOrder(const Order &order) override;
    void cancelOrder(OrderId orderId) override;
    void modifyOrder(OrderId orderId, Quantity newQuantity) override;
    std::vector<Trade> match() override;
    Index getOrderCount() const override;

    Price getBestBid() const override;
    Price getBestAsk() const override;

  private:
    using OrderList = std::list<Order>;
    using BidsMap = std::map<Price, OrderList, std::greater<Price>>; // Highest price first
    using AsksMap = std::map<Price, OrderList, std::less<Price>>;    // Lowest price first

    BidsMap bids_;
    AsksMap asks_;

    // For O(1) access to orders by ID
    struct OrderLocation
    {
        bool isBuy;
        Price price;
        OrderList::iterator iterator;
    };

    using OrderLookupMap = std::unordered_map<OrderId, OrderLocation>; // Fast order lookup by ID

    OrderLookupMap orderLookup_;
};

} // namespace hft
