#include "array_order_book.hpp"
#include <iostream>
#include <stdexcept>

namespace hft
{
ArrayOrderBook::ArrayOrderBook(Price minPrice, Price maxPrice, Price tickSize)
    : minPrice_(minPrice), maxPrice_(maxPrice), tickSize_(tickSize), numLevels_(0), bidLevels_(), askLevels_(),
      activeBidLevels_(), activeAskLevels_(), cachedBestBid_(0), cachedBestAsk_(std::numeric_limits<Price>::max())
{
    // Validate configuration
    if (minPrice >= maxPrice)
    {
        throw std::invalid_argument("minPrice must be less than maxPrice");
    }
    if (tickSize == 0)
    {
        throw std::invalid_argument("tickSize must be greater than 0");
    }
    if ((maxPrice - minPrice) % tickSize != 0)
    {
        throw std::invalid_argument("Price range must be evenly divisible by tickSize");
    }

    numLevels_ = ((maxPrice_ - minPrice_) / tickSize_) + 1;
    bidLevels_.resize(numLevels_);
    askLevels_.resize(numLevels_);
    activeBidLevels_.assign(numLevels_, false);
    activeAskLevels_.assign(numLevels_, false);
}

void ArrayOrderBook::addOrder(const Order &order)
{
    if (orderLookup_.find(order.id) != orderLookup_.end())
    {
        return; // Reject duplicate OrderId
    }

    // Validate price is within bounds and aligned to tick
    if (!isValidPrice(order.price))
    {
        // Silently reject invalid orders (out of range or not tick-aligned)
        return;
    }

    Index indexToInsert = priceToIndex(order.price);

    if (order.side == Side::Buy)
    {
        // Insert order into order list at appropriate index
        auto &orderList = bidLevels_[indexToInsert];
        orderList.push_back(order);

        // Update the active BidLevels and cache
        activeBidLevels_[indexToInsert] = true;
        if (order.price > cachedBestBid_)
        {
            cachedBestBid_ = order.price;
        }

        // Store iterator in lookup
        orderLookup_[order.id] = {true, indexToInsert, --orderList.end()};
    }
    else
    {

        auto &orderList = askLevels_[indexToInsert];
        orderList.push_back(order);

        // Update the active AskLevels and cache
        activeAskLevels_[indexToInsert] = true;
        if (order.price < cachedBestAsk_)
        {
            cachedBestAsk_ = order.price;
        }

        // Store iterator in lookup
        orderLookup_[order.id] = {false, indexToInsert, --orderList.end()};
    }
}

void ArrayOrderBook::cancelOrder(OrderId orderId)
{
    auto orderIterator = orderLookup_.find(orderId);
    if (orderIterator == orderLookup_.end())
    {
        return; // Order not found
    }

    const auto &orderLocation = orderIterator->second;
    Index indexToCancel = orderLocation.arrayIndex;

    if (orderLocation.isBuy)
    {
        bidLevels_[indexToCancel].erase(orderLocation.iterator);

        // If emptied price level must update activeBidLevels and potentially update Cache
        if (bidLevels_[indexToCancel].empty())
        {
            activeBidLevels_[indexToCancel] = false;

            if (indexToPrice(indexToCancel) == cachedBestBid_)
            {
                updateBestBidCache();
            }
        }
    }
    else
    {
        askLevels_[indexToCancel].erase(orderLocation.iterator);

        // If emptied price level must update activeBidLevels and potentially update Cache
        if (askLevels_[indexToCancel].empty())
        {
            activeAskLevels_[indexToCancel] = false;

            if (indexToPrice(indexToCancel) == cachedBestAsk_)
            {
                updateBestAskCache();
            }
        }
    }

    orderLookup_.erase(orderIterator);
}

void ArrayOrderBook::modifyOrder(OrderId orderId, Quantity newQuantity)
{
    auto orderIterator = orderLookup_.find(orderId);
    if (orderIterator == orderLookup_.end())
    {
        return; // Couldn't find order (non existent)
    }

    // If modifying to zero quantity, cancel instead
    if (newQuantity == 0)
    {
        cancelOrder(orderId);
        return;
    }

    const auto &orderLocation = orderIterator->second;

    orderLocation.iterator->quantity = newQuantity;
}

std::vector<Trade> ArrayOrderBook::match()
{
    std::vector<Trade> trades;

    while (cachedBestBid_ >= cachedBestAsk_)
    {
        Index bidIndex = priceToIndex(cachedBestBid_);
        Index askIndex = priceToIndex(cachedBestAsk_);

        auto &bidList = bidLevels_[bidIndex];
        auto &askList = askLevels_[askIndex];

        // Price time priority
        Order &bidOrder = bidList.front();
        Order &askOrder = askList.front();

        Quantity tradeQty = std::min(bidOrder.quantity, askOrder.quantity);

        // Create trade
        trades.push_back({bidOrder.id, askOrder.id, askOrder.price, tradeQty});

        // Update quantities
        bidOrder.quantity -= tradeQty;
        askOrder.quantity -= tradeQty;

        // Clean up empty price levels (must update caches and activeLevels on empty)
        if (bidOrder.quantity == 0)
        {
            orderLookup_.erase(bidOrder.id);
            bidList.pop_front();
            if (bidList.empty())
            {
                activeBidLevels_[bidIndex] = false;
                updateBestBidCache();
            }
        }

        if (askOrder.quantity == 0)
        {
            orderLookup_.erase(askOrder.id);
            askList.pop_front();
            if (askList.empty())
            {
                activeAskLevels_[askIndex] = false;
                updateBestAskCache();
            }
        }
    }
    return trades;
}

// Helpers
Index ArrayOrderBook::priceToIndex(Price price) const
{
    return (price - minPrice_) / tickSize_;
}

Price ArrayOrderBook::indexToPrice(Index index) const
{
    return minPrice_ + (index * tickSize_);
}

bool ArrayOrderBook::isValidPrice(Price price) const
{
    // Check if price is in range
    if (price < minPrice_ || price > maxPrice_)
    {
        return false;
    }
    // Check if price is aligned to tick size
    if ((price - minPrice_) % tickSize_ != 0)
    {
        return false;
    }
    return true;
}

void ArrayOrderBook::updateBestBidCache()
{
    // Scan from highest price to lowest (bids want highest price)
    for (int i = numLevels_ - 1; i >= 0; --i)
    {
        if (activeBidLevels_[i])
        {
            cachedBestBid_ = indexToPrice(i);
            return;
        }
    }
    // No bids found
    cachedBestBid_ = 0;
}

void ArrayOrderBook::updateBestAskCache()
{
    // Scan from lowest price to highest (asks want lowest price)
    for (Index i = 0; i < numLevels_; ++i)
    {
        if (activeAskLevels_[i])
        {
            cachedBestAsk_ = indexToPrice(i);
            return;
        }
    }
    // No asks found
    cachedBestAsk_ = std::numeric_limits<Price>::max();
}

// Public APIS for future GUI
Price ArrayOrderBook::getBestBid() const
{
    return cachedBestBid_;
}

Price ArrayOrderBook::getBestAsk() const
{
    return cachedBestAsk_;
}

Index ArrayOrderBook::getOrderCount() const
{
    return orderLookup_.size();
}

} // namespace hft
